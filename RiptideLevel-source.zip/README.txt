RiptideLevel
============
Paper/Purpur plugin: Riptide tridents at or above a chosen level work without water or rain.
Lower levels stay vanilla. Edit plugins/RiptideLevel/config.yml, then /riptidelevel reload.

HOW TO BUILD THE JAR (pick one)

A) No install, using GitHub (easiest)
 1. Make a free GitHub account and create a new empty repository.
 2. Upload everything in this folder to it (keep the folder structure, including .github).
 3. Open the repo > Actions tab > "Build plugin" > wait for the green check.
 4. Open that run and download the "RiptideLevel" artifact. Unzip it to get RiptideLevel.jar.

B) On your PC
 1. Install JDK 21 and Maven.
 2. In this folder run:  mvn package
 3. Your plugin is target/RiptideLevel.jar

INSTALL
 1. Put RiptideLevel.jar in your server's plugins folder.
 2. Fully restart the server (not /reload).
 3. Run /plugins and check RiptideLevel is green.
 4. Do NOT also install other "Riptide without water" plugins.
