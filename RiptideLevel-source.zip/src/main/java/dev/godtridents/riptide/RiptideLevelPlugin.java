package dev.godtridents.riptide;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class RiptideLevelPlugin extends JavaPlugin implements Listener {

    private final Map<UUID, Long> lastUse = new HashMap<>();

    private int minLevel;
    private int maxLevel;
    private int cooldownTicks;
    private int spinTicks;
    private double spinDamage;
    private double speedMultiplier;
    private double maxSpeed;
    private boolean useDurability;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        loadSettings();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("RiptideLevel enabled. Riptide " + minLevel + "-" + maxLevel + " works without water.");
    }

    private void loadSettings() {
        reloadConfig();
        minLevel = getConfig().getInt("min-riptide-level", 10);
        maxLevel = getConfig().getInt("max-riptide-level", 255);
        cooldownTicks = getConfig().getInt("cooldown-ticks", 20);
        spinTicks = Math.max(1, getConfig().getInt("spin-duration-ticks", 20));
        spinDamage = Math.max(0.0, getConfig().getDouble("spin-damage", 8.0));
        speedMultiplier = getConfig().getDouble("speed-multiplier", 1.0);
        maxSpeed = getConfig().getDouble("max-speed", 4.0);
        useDurability = getConfig().getBoolean("use-durability", true);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            loadSettings();
            sender.sendMessage("RiptideLevel config reloaded (Riptide " + minLevel + "-" + maxLevel + ").");
            return true;
        }
        sender.sendMessage("Usage: /" + label + " reload");
        return true;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        lastUse.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        if (event.useItemInHand() == Event.Result.DENY) {
            return;
        }

        EquipmentSlot hand = event.getHand();
        if (hand != EquipmentSlot.HAND && hand != EquipmentSlot.OFF_HAND) {
            return;
        }

        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.SPECTATOR) {
            return;
        }

        // Do not launch when the player is just opening a chest, door, etc.
        if (action == Action.RIGHT_CLICK_BLOCK && !player.isSneaking()) {
            Block clicked = event.getClickedBlock();
            if (clicked != null && clicked.getType().isInteractable()) {
                return;
            }
        }

        ItemStack held = player.getInventory().getItem(hand);
        if (held == null || held.getType() != Material.TRIDENT) {
            return;
        }

        int level = held.getEnchantmentLevel(Enchantment.RIPTIDE);
        if (level <= 0 || level < minLevel || level > maxLevel) {
            return;
        }

        // In water or rain the normal vanilla riptide already works, so stay out of its way.
        if (player.isInWaterOrRain()) {
            return;
        }

        long now = System.currentTimeMillis();
        Long last = lastUse.get(player.getUniqueId());
        if (last != null && now - last < cooldownTicks * 50L) {
            return;
        }

        ItemMeta meta = held.getItemMeta();
        if (useDurability && meta instanceof Damageable damageable && !meta.isUnbreakable()) {
            int max = held.getType().getMaxDurability();
            // Vanilla refuses to use a trident that is one hit from breaking.
            if (damageable.getDamage() + 1 >= max) {
                return;
            }
            int unbreaking = held.getEnchantmentLevel(Enchantment.UNBREAKING);
            if (unbreaking <= 0 || ThreadLocalRandom.current().nextInt(unbreaking + 1) == 0) {
                damageable.setDamage(damageable.getDamage() + 1);
                held.setItemMeta(damageable);
                player.getInventory().setItem(hand, held);
            }
        }

        lastUse.put(player.getUniqueId(), now);

        // Same launch as vanilla: hop off the ground, then push in the look direction.
        Location loc = player.getLocation();
        if (player.isOnGround()) {
            Location up = loc.clone().add(0, 1.2, 0);
            if (up.getBlock().isPassable() && up.clone().add(0, 1, 0).getBlock().isPassable()) {
                player.teleport(up);
            }
        }

        double speed = Math.min(3.0 * (1.0 + level) / 4.0 * speedMultiplier, maxSpeed);
        Vector push = player.getLocation().getDirection().normalize().multiply(speed);

        // Real vanilla spin-attack pose and entity damage.
        player.startRiptideAttack(spinTicks, (float) spinDamage, held);
        player.setVelocity(player.getVelocity().add(push));

        player.getWorld().playSound(player.getLocation(), Sound.ITEM_TRIDENT_RIPTIDE_3, SoundCategory.PLAYERS, 1.0f, 1.0f);
    }
}
